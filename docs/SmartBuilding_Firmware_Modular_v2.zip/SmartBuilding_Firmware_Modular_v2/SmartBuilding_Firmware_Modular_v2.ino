#include <WiFi.h>
#include <WebServer.h>
#include <DNSServer.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>
#include <Preferences.h>

#include <lmic.h>
#include <hal/hal.h>
#include <SPI.h>

#include <Wire.h>

#include "BuildConfig.h"
#include "src/framework/TelemetryTypes.h"
#include "src/framework/SensorRegistry.h"
#include "src/framework/PayloadRegistry.h"

WebServer server(80);
DNSServer dnsServer;
Preferences preferences;

const byte DNS_PORT = 53;

// Hotspot settings
const char* apSSID = "LILYGO_Config";
const char* apPassword = "12345678";

// Wi-Fi network that BOTH ESP32 and Raspberry Pi must use
const char* staSSID = "Ehab's Tab S9";
const char* staPassword = "123ahmed456";

// Raspberry Pi provisioning server
const char* provisionServer = "http://10.226.58.127:8000/provision";
const char* provisionOptionsServer = "http://10.226.58.127:8000/provision-options";
const char* FIRMWARE_VERSION = "1.0.0";

bool configMode = true;
unsigned long configStartTime = 0;
const unsigned long configWindow = 300000;  // 5 minutes

String chipMac = "";
String nodeType = "environment";
String buildingName = "main test building";
String floorName = "1";
String roomName = "room A";
String deviceLabel = "EnvNode-roomA";
// ===== Selected sensor profile =====
int selectedProfileId = 0;
String selectedProfileCode = "";
int selectedProfileVersion = 1;
int selectedPayloadVersion = 1;
String selectedPayloadEncoderKey = "";
String selectedSensorModuleKey = "";
String selectedSensorConfigurationJson = "{}";
int selectedUplinkIntervalSeconds = 60;
int selectedRoomId = 0;

String selectedConfigurationStatus = "";
String selectedConfigurationChecksum = "";

// ===== LoRaWAN saved credentials =====
bool hasSavedLoRaWANCreds = false;
bool hasSavedRuntimeConfig = false;
bool lmicStarted = false;
bool joined = false;

String savedDevEuiStr = "";
String savedJoinEuiStr = "";
String savedAppKeyStr = "";

uint8_t savedDevEUI[8];
uint8_t savedJoinEUI[8];
uint8_t savedAppKey[16];

static osjob_t sendjob;
const unsigned TX_INTERVAL = 60;  // seconds

const lmic_pinmap lmic_pins = {
  .nss = 18,
  .rxtx = LMIC_UNUSED_PIN,
  .rst = 14,
  .dio = {26, 33, LMIC_UNUSED_PIN},
};

String getChipMac() {
  uint64_t chipid = ESP.getEfuseMac();
  char macStr[13];
  snprintf(macStr, sizeof(macStr), "%04X%08X",
           (uint16_t)(chipid >> 32),
           (uint32_t)chipid);
  return String(macStr);
}

int hexCharToValue(char c) {
  if (c >= '0' && c <= '9') return c - '0';
  if (c >= 'A' && c <= 'F') return c - 'A' + 10;
  if (c >= 'a' && c <= 'f') return c - 'a' + 10;
  return -1;
}

bool hexStringToBytes(String hex, uint8_t* out, int expectedLen) {
  hex.trim();

  if ((int)hex.length() != expectedLen * 2) {
    Serial.println("Hex string length mismatch");
    return false;
  }

  for (int i = 0; i < expectedLen; i++) {
    int high = hexCharToValue(hex[i * 2]);
    int low  = hexCharToValue(hex[i * 2 + 1]);

    if (high < 0 || low < 0) {
      Serial.println("Invalid hex character found");
      return false;
    }

    out[i] = (high << 4) | low;
  }

  return true;
}

void reverseBytes(uint8_t* data, int len) {
  for (int i = 0; i < len / 2; i++) {
    uint8_t temp = data[i];
    data[i] = data[len - 1 - i];
    data[len - 1 - i] = temp;
  }
}

void printByteArray(const uint8_t* data, int len, const char* label) {
  Serial.print(label);
  Serial.print(": ");
  for (int i = 0; i < len; i++) {
    if (data[i] < 0x10) Serial.print("0");
    Serial.print(data[i], HEX);
  }
  Serial.println();
}

bool loadSavedLoRaWANCredentials() {
  preferences.begin("prov", true);

  bool provisioned = preferences.getBool("provisioned", false);
  savedDevEuiStr = preferences.getString("dev_eui", "");
  savedJoinEuiStr = preferences.getString("join_eui", "");
  savedAppKeyStr = preferences.getString("app_key", "");

  preferences.end();

  Serial.println("---- Loading LoRaWAN credentials from flash ----");
  Serial.print("Provisioned: ");
  Serial.println(provisioned ? "true" : "false");
  Serial.print("Saved DevEUI : ");
  Serial.println(savedDevEuiStr);
  Serial.print("Saved JoinEUI: ");
  Serial.println(savedJoinEuiStr);
  Serial.print("Saved AppKey : ");
  Serial.println(savedAppKeyStr);

  if (!provisioned) {
    Serial.println("Device is not provisioned yet");
    return false;
  }

  bool ok1 = hexStringToBytes(savedDevEuiStr, savedDevEUI, 8);
  bool ok2 = hexStringToBytes(savedJoinEuiStr, savedJoinEUI, 8);
  bool ok3 = hexStringToBytes(savedAppKeyStr, savedAppKey, 16);

  if (!(ok1 && ok2 && ok3)) {
    Serial.println("Failed to convert saved credentials to byte arrays");
    return false;
  }

  reverseBytes(savedDevEUI, 8);
  reverseBytes(savedJoinEUI, 8);

  Serial.println("LoRaWAN credentials prepared for LMIC join:");
  printByteArray(savedDevEUI, 8, "DevEUI reversed");
  printByteArray(savedJoinEUI, 8, "JoinEUI reversed");
  printByteArray(savedAppKey, 16, "AppKey normal");

  Serial.println("LoRaWAN credentials loaded successfully");
  return true;
}

// ===== LMIC credential callbacks =====
void os_getArtEui(u1_t* buf) {
  memcpy(buf, savedJoinEUI, 8);
}

void os_getDevEui(u1_t* buf) {
  memcpy(buf, savedDevEUI, 8);
}

void os_getDevKey(u1_t* buf) {
  memcpy(buf, savedAppKey, 16);
}

void do_send(osjob_t* j) {
  uint32_t effectiveIntervalSeconds = 60;
  if (selectedUplinkIntervalSeconds >= 5 &&
      selectedUplinkIntervalSeconds <= 86400) {
    effectiveIntervalSeconds = static_cast<uint32_t>(selectedUplinkIntervalSeconds);
  }

  if (!joined) {
    Serial.println("Not joined yet, not sending");
    return;
  }

  if (LMIC.opmode & OP_TXRXPEND) {
    Serial.println("OP_TXRXPEND, uplink postponed");
  } else {
    SensorReadingSet readings;
    bool readingSuccess = SensorRegistry::read(readings);

    if (!readingSuccess) {
      Serial.println("No valid sensor readings; uplink skipped");
    } else {
      PayloadBuffer payload;
      bool encodingSuccess = PayloadRegistry::encode(
        selectedPayloadEncoderKey,
        readings,
        payload
      );

      if (!encodingSuccess || payload.length == 0) {
        Serial.println("Payload encoding failed; uplink skipped");
      } else if (payload.length > MAX_LORAWAN_PAYLOAD_BYTES) {
        Serial.println("Encoded payload exceeds the firmware payload limit");
      } else {
        Serial.println("===== PROFILE-DRIVEN UPLINK =====");
        Serial.print("Build preset: "); Serial.println(FW_BUILD_NAME);
        Serial.print("Profile code: "); Serial.println(selectedProfileCode);
        Serial.print("Sensor module: "); Serial.println(selectedSensorModuleKey);
        Serial.print("Profile version: "); Serial.println(selectedProfileVersion);
        Serial.print("Payload encoder: "); Serial.println(selectedPayloadEncoderKey);
        Serial.print("Payload version: "); Serial.println(selectedPayloadVersion);
        Serial.print("Payload length: "); Serial.print(payload.length); Serial.println(" bytes");
        PayloadRegistry::printHex(payload);

        LMIC_setTxData2(1, payload.bytes, payload.length, 0);
        Serial.println("Profile-driven uplink queued");
      }
    }
  }

  Serial.print("Next uplink in ");
  Serial.print(effectiveIntervalSeconds);
  Serial.println(" seconds");

  os_setTimedCallback(
    j,
    os_getTime() + sec2osticks(effectiveIntervalSeconds),
    do_send
  );
}

void onEvent(ev_t ev) {
  switch (ev) {
    case EV_JOINING:
      Serial.println("EV_JOINING");
      break;

    case EV_JOINED:
      Serial.println("EV_JOINED");
      joined = true;
      LMIC_setLinkCheckMode(0);
      do_send(&sendjob);
      break;

    case EV_TXSTART:
      Serial.println("EV_TXSTART");
      break;

    case EV_TXCOMPLETE:
      Serial.println("EV_TXCOMPLETE");

      if (LMIC.txrxFlags & TXRX_ACK) {
        Serial.println("Received ack");
      }

      if (LMIC.dataLen) {
        Serial.print("Received ");
        Serial.print(LMIC.dataLen);
        Serial.println(" bytes downlink");
      }
      break;

    case EV_JOIN_FAILED:
      Serial.println("EV_JOIN_FAILED");
      break;

    case EV_REJOIN_FAILED:
      Serial.println("EV_REJOIN_FAILED");
      break;

    default:
      break;
  }
}

void startLoRaWANJoin() {
  if (!hasSavedLoRaWANCreds) {
    Serial.println("Cannot start LMIC join: no saved credentials");
    return;
  }

  if (lmicStarted) {
    Serial.println("LMIC already started");
    return;
  }

  Serial.println("Starting LMIC...");

  SPI.begin(5, 19, 27, 18);
  delay(100);

  os_init();
  LMIC_reset();
  LMIC_setClockError(MAX_CLOCK_ERROR * 1 / 100);
  LMIC_startJoining();

  lmicStarted = true;
  joined = false;

  Serial.println("LMIC OTAA join started");
}

void saveProvisioningData(
  String status,
  String device_id,
  String dev_eui,
  String join_eui,
  String app_key,

  String node_type,

  int profile_id,
  String profile_code,
  int profile_version,
  int payload_version,
  String payload_encoder_key,
  String sensor_module_key,
  String sensor_configuration_json,
  int uplink_interval_seconds,
  String firmware_version,

  String configuration_status,
  String configuration_checksum,

  String building,
  String floor,
  String room,
  int room_id,
  String label
) {
  preferences.begin("prov", false);

  // General status
  preferences.putBool(
    "provisioned",
    true
  );

  preferences.putString(
    "status",
    status
  );

  // LoRaWAN credentials
  preferences.putString(
    "device_id",
    device_id
  );

  preferences.putString(
    "dev_eui",
    dev_eui
  );

  preferences.putString(
    "join_eui",
    join_eui
  );

  preferences.putString(
    "app_key",
    app_key
  );

  // Profile identity
  preferences.putString(
    "node_type",
    node_type
  );

  preferences.putInt(
    "profile_id",
    profile_id
  );

  preferences.putString(
    "profile_code",
    profile_code
  );

  preferences.putInt(
    "profile_ver",
    profile_version
  );

  preferences.putInt(
    "payload_ver",
    payload_version
  );

  preferences.putString(
    "encoder_key",
    payload_encoder_key
  );

  preferences.putString(
    "sensor_module",
    sensor_module_key
  );

  preferences.putString(
    "sensor_config",
    sensor_configuration_json
  );

  preferences.putInt(
    "uplink_sec",
    uplink_interval_seconds
  );

  preferences.putString(
    "fw_version",
    firmware_version
  );

  preferences.putString(
    "config_status",
    configuration_status
  );

  preferences.putString(
    "config_sum",
    configuration_checksum
  );

  // Location
  preferences.putString(
    "building",
    building
  );

  preferences.putString(
    "floor",
    floor
  );

  preferences.putString(
    "room",
    room
  );

  preferences.putInt(
    "room_id",
    room_id
  );

  preferences.putString(
    "label",
    label
  );

  preferences.end();

  Serial.println(
    "Profile-driven provisioning data saved to flash"
  );
}

void printSavedProvisioningData() {
  preferences.begin("prov", true);

  bool provisioned = preferences.getBool(
    "provisioned",
    false
  );

  Serial.println(
    "---- Saved Provisioning Data ----"
  );

  Serial.print("provisioned: ");
  Serial.println(
    provisioned
      ? "true"
      : "false"
  );

  if (provisioned) {
    Serial.print("status: ");
    Serial.println(
      preferences.getString(
        "status",
        ""
      )
    );

    Serial.print("device_id: ");
    Serial.println(
      preferences.getString(
        "device_id",
        ""
      )
    );

    Serial.print("dev_eui: ");
    Serial.println(
      preferences.getString(
        "dev_eui",
        ""
      )
    );

    Serial.print("join_eui: ");
    Serial.println(
      preferences.getString(
        "join_eui",
        ""
      )
    );

    Serial.print("app_key: ");
    Serial.println(
      preferences.getString(
        "app_key",
        ""
      )
    );

    Serial.print("node_type: ");
    Serial.println(
      preferences.getString(
        "node_type",
        ""
      )
    );

    Serial.print("profile_id: ");
    Serial.println(
      preferences.getInt(
        "profile_id",
        0
      )
    );

    Serial.print("profile_code: ");
    Serial.println(
      preferences.getString(
        "profile_code",
        ""
      )
    );

    Serial.print("profile_version: ");
    Serial.println(
      preferences.getInt(
        "profile_ver",
        0
      )
    );

    Serial.print("payload_version: ");
    Serial.println(
      preferences.getInt(
        "payload_ver",
        0
      )
    );

    Serial.print("payload_encoder_key: ");
    Serial.println(
      preferences.getString(
        "encoder_key",
        ""
      )
    );

    Serial.print("sensor_module_key: ");
    Serial.println(
      preferences.getString(
        "sensor_module",
        ""
      )
    );

    Serial.print("sensor_configuration: ");
    Serial.println(
      preferences.getString(
        "sensor_config",
        "{}"
      )
    );

    Serial.print("uplink_interval_seconds: ");
    Serial.println(
      preferences.getInt(
        "uplink_sec",
        0
      )
    );

    Serial.print("firmware_version: ");
    Serial.println(
      preferences.getString(
        "fw_version",
        ""
      )
    );

    Serial.print("configuration_status: ");
    Serial.println(
      preferences.getString(
        "config_status",
        ""
      )
    );

    Serial.print("configuration_checksum: ");
    Serial.println(
      preferences.getString(
        "config_sum",
        ""
      )
    );

    Serial.print("building: ");
    Serial.println(
      preferences.getString(
        "building",
        ""
      )
    );

    Serial.print("floor: ");
    Serial.println(
      preferences.getString(
        "floor",
        ""
      )
    );

    Serial.print("room: ");
    Serial.println(
      preferences.getString(
        "room",
        ""
      )
    );

    Serial.print("room_id: ");
    Serial.println(
      preferences.getInt(
        "room_id",
        0
      )
    );

    Serial.print("label: ");
    Serial.println(
      preferences.getString(
        "label",
        ""
      )
    );
  }

  preferences.end();

  Serial.println(
    "--------------------------------"
  );
}

bool loadSavedRuntimeConfiguration() {
  preferences.begin(
    "prov",
    true
  );

  bool provisioned = preferences.getBool(
    "provisioned",
    false
  );

  if (!provisioned) {
    preferences.end();

    Serial.println(
      "No saved runtime configuration found"
    );

    return false;
  }

  // =========================================================
  // PROFILE AND PAYLOAD CONFIGURATION
  // =========================================================

  selectedProfileId = preferences.getInt(
    "profile_id",
    0
  );

  selectedProfileCode = preferences.getString(
    "profile_code",
    ""
  );

  selectedProfileVersion = preferences.getInt(
    "profile_ver",
    1
  );

  selectedPayloadVersion = preferences.getInt(
    "payload_ver",
    1
  );

  selectedPayloadEncoderKey = preferences.getString(
    "encoder_key",
    ""
  );

  selectedSensorModuleKey = preferences.getString(
    "sensor_module",
    ""
  );

  selectedSensorConfigurationJson = preferences.getString(
    "sensor_config",
    "{}"
  );

  selectedUplinkIntervalSeconds = preferences.getInt(
    "uplink_sec",
    60
  );

  nodeType = preferences.getString(
    "node_type",
    "environment"
  );

  selectedConfigurationStatus = preferences.getString(
    "config_status",
    ""
  );

  selectedConfigurationChecksum = preferences.getString(
    "config_sum",
    ""
  );

  // =========================================================
  // LOCATION AND DEVICE INFORMATION
  // =========================================================

  buildingName = preferences.getString(
    "building",
    buildingName
  );

  floorName = preferences.getString(
    "floor",
    floorName
  );

  roomName = preferences.getString(
    "room",
    roomName
  );

  selectedRoomId = preferences.getInt(
    "room_id",
    0
  );

  deviceLabel = preferences.getString(
    "label",
    deviceLabel
  );

  preferences.end();

  // =========================================================
  // NORMALIZE VALUES
  // =========================================================

  selectedProfileCode.trim();
  selectedPayloadEncoderKey.trim();
  selectedSensorModuleKey.trim();
  nodeType.trim();

  if (
    selectedUplinkIntervalSeconds < 5 ||
    selectedUplinkIntervalSeconds > 86400
  ) {
    Serial.println(
      "Invalid saved uplink interval; using 60 seconds"
    );

    selectedUplinkIntervalSeconds = 60;
  }

  bool valid = (
    selectedProfileId > 0 &&
    selectedProfileCode.length() > 0 &&
    selectedProfileVersion > 0 &&
    selectedPayloadVersion > 0 &&
    selectedPayloadEncoderKey.length() > 0 &&
    selectedSensorModuleKey.length() > 0
  );

  // =========================================================
  // DIAGNOSTIC OUTPUT
  // =========================================================

  Serial.println(
    "---- Loaded Runtime Configuration ----"
  );

  Serial.print("Valid: ");
  Serial.println(
    valid
      ? "true"
      : "false"
  );

  Serial.print("Profile ID: ");
  Serial.println(
    selectedProfileId
  );

  Serial.print("Profile code: ");
  Serial.println(
    selectedProfileCode
  );

  Serial.print("Profile version: ");
  Serial.println(
    selectedProfileVersion
  );

  Serial.print("Payload version: ");
  Serial.println(
    selectedPayloadVersion
  );

  Serial.print("Payload encoder: ");
  Serial.println(
    selectedPayloadEncoderKey
  );

  Serial.print("Sensor module: ");
  Serial.println(selectedSensorModuleKey);

  Serial.print("Sensor configuration: ");
  Serial.println(selectedSensorConfigurationJson);

  Serial.print("Uplink interval: ");
  Serial.println(
    selectedUplinkIntervalSeconds
  );

  Serial.print("Node type: ");
  Serial.println(
    nodeType
  );

  Serial.print("Configuration status: ");
  Serial.println(
    selectedConfigurationStatus
  );

  Serial.print("Room ID: ");
  Serial.println(
    selectedRoomId
  );

  Serial.println(
    "--------------------------------------"
  );

  return valid;
}

void stopConfigPortal() {
  dnsServer.stop();
  server.stop();
  WiFi.softAPdisconnect(true);
  WiFi.mode(WIFI_STA);
  configMode = false;
  Serial.println("Config portal stopped");
}

bool connectToWiFi() {
  WiFi.mode(WIFI_AP_STA);
  WiFi.begin(staSSID, staPassword);

  Serial.print("Connecting to WiFi");
  unsigned long start = millis();

  while (WiFi.status() != WL_CONNECTED && millis() - start < 20000) {
    delay(500);
    Serial.print(".");
  }

  Serial.println();

  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("Connected to WiFi");
    Serial.print("ESP32 STA IP: ");
    Serial.println(WiFi.localIP());
    return true;
  }

  Serial.println("Failed to connect to WiFi");
  return false;
}

String fetchProvisionOptionsJson() {
  if (WiFi.status() != WL_CONNECTED) {
    Serial.println("Cannot fetch provision options: WiFi not connected");
    return "";
  }

  HTTPClient http;
  http.begin(provisionOptionsServer);

  Serial.println("Fetching provision options...");
  Serial.println(provisionOptionsServer);

  int httpCode = http.GET();
  String response = http.getString();

  Serial.print("Options HTTP code: ");
  Serial.println(httpCode);
  Serial.println("Options response:");
  Serial.println(response);

  http.end();

  if (httpCode == 200) {
    return response;
  }

  return "";
}

String buildNodeTypeOptions(JsonArray nodeTypes) {
  String html = "";

  for (JsonVariant v : nodeTypes) {
    String nt = v.as<String>();
    html += "<option value='" + nt + "'";
    if (nt == nodeType) html += " selected";
    html += ">" + nt + "</option>";
  }

  if (html.length() == 0) {
    html += "<option value='environment'>environment</option>";
    html += "<option value='occupancy'>occupancy</option>";
    html += "<option value='safety'>safety</option>";
    html += "<option value='energy'>energy</option>";
  }

  return html;
}

String buildBuildingOptions(JsonObject buildings) {
  String html = "";

  for (JsonPair building : buildings) {
    String b = String(building.key().c_str());
    html += "<option value='" + b + "'";
    if (b == buildingName) html += " selected";
    html += ">" + b + "</option>";
  }

  if (html.length() == 0) {
    html += "<option value='Siemenshalle'>Siemenshalle</option>";
  }

  return html;
}

String buildFloorOptions(JsonObject buildings) {
  String html = "";

  if (buildings.containsKey(buildingName)) {
    JsonObject floors = buildings[buildingName].as<JsonObject>();

    for (JsonPair floor : floors) {
      String f = String(floor.key().c_str());
      html += "<option value='" + f + "'";
      if (f == floorName) html += " selected";
      html += ">" + f + "</option>";
    }
  }

  if (html.length() == 0) {
    html += "<option value='0'>0</option>";
  }

  return html;
}

String buildRoomOptions(JsonObject buildings) {
  String html = "";

  if (buildings.containsKey(buildingName)) {
    JsonObject floors = buildings[buildingName].as<JsonObject>();

    if (floors.containsKey(floorName)) {
      JsonObject rooms = floors[floorName].as<JsonObject>();

      for (JsonPair room : rooms) {
        String r = String(room.key().c_str());
        html += "<option value='" + r + "'";
        if (r == roomName) html += " selected";
        html += ">" + r + "</option>";
      }
    }
  }

  if (html.length() == 0) {
    html += "<option value='Main Hall'>Main Hall</option>";
  }

  return html;
}

void handleRoot() {
  String optionsJson = fetchProvisionOptionsJson();

  if (optionsJson.length() == 0) {
    optionsJson =
      "{\"status\":\"offline\","
      "\"profiles\":[],"
      "\"node_types\":["
      "\"environment\","
      "\"occupancy\","
      "\"safety\","
      "\"energy\","
      "\"multi\""
      "],"
      "\"buildings\":{}}";
  }

  // Protect the JSON before inserting it into JavaScript.
  optionsJson.replace("\\", "\\\\");
  optionsJson.replace("`", "\\`");
  optionsJson.replace("</script>", "<\\/script>");

  String html =
    "<!DOCTYPE html>"
    "<html>"
    "<head>"
    "<meta charset='UTF-8'>";

  html +=
    "<meta name='viewport' "
    "content='width=device-width,initial-scale=1.0'>";

  html += "<title>LILYGO Sensor Provisioning</title>";

  // =========================================================
  // CSS
  // =========================================================

  html += "<style>";

  html += "*{box-sizing:border-box;}";

  html +=
    "body{"
    "margin:0;"
    "font-family:Arial,sans-serif;"
    "background:#08111f;"
    "color:#f8fafc;"
    "padding:18px;"
    "}";

  html +=
    ".card{"
    "max-width:620px;"
    "margin:auto;"
    "background:#101b2d;"
    "padding:20px;"
    "border:1px solid #2a3d58;"
    "border-radius:16px;"
    "box-shadow:0 16px 40px rgba(0,0,0,.35);"
    "}";

  html += "h2{margin:0 0 6px;}";

  html +=
    ".subtitle{"
    "margin:0 0 18px;"
    "color:#94a3b8;"
    "font-size:13px;"
    "line-height:1.5;"
    "}";

  html +=
    ".info,.profile-info{"
    "font-size:13px;"
    "background:#17253b;"
    "padding:12px;"
    "border:1px solid #2a3d58;"
    "border-radius:10px;"
    "margin-bottom:16px;"
    "line-height:1.55;"
    "}";

  html +=
    ".profile-info{"
    "display:none;"
    "background:#0f2137;"
    "}";

  html +=
    ".profile-title{"
    "font-size:15px;"
    "font-weight:bold;"
    "color:#93c5fd;"
    "margin-bottom:6px;"
    "}";

  html += ".muted{color:#94a3b8;}";

  html +=
    "label{"
    "display:block;"
    "font-weight:bold;"
    "margin-top:12px;"
    "}";

  html +=
    "select,input{"
    "width:100%;"
    "padding:11px;"
    "margin-top:6px;"
    "border:1px solid #415875;"
    "border-radius:9px;"
    "background:#17253b;"
    "color:#f8fafc;"
    "}";

  html +=
    "input[type=submit]{"
    "margin-top:18px;"
    "background:#2563eb;"
    "color:white;"
    "font-weight:bold;"
    "border:none;"
    "cursor:pointer;"
    "}";

  html +=
    "input[type=submit]:hover{"
    "background:#1d4ed8;"
    "}";

  html +=
    ".error{"
    "padding:10px;"
    "border:1px solid #ef4444;"
    "background:#7f1d1d;"
    "color:#fecaca;"
    "border-radius:8px;"
    "margin-bottom:14px;"
    "}";

  html +=
    ".small{"
    "font-size:11px;"
    "color:#94a3b8;"
    "margin-top:14px;"
    "line-height:1.5;"
    "}";

  html += "</style>";
  html += "</head>";

  // =========================================================
  // PAGE CONTENT
  // =========================================================

  html += "<body>";
  html += "<div class='card'>";

  html += "<h2>LILYGO Sensor Provisioning</h2>";

  html +=
    "<p class='subtitle'>"
    "Select the installed sensor profile and its physical room. "
    "TTN, ThingsBoard, payload and alarm settings are applied "
    "automatically by the backend."
    "</p>";

  html += "<div class='info'>";

  html +=
    "<div><b>Chip MAC:</b> "
    + chipMac
    + "</div>";

  html +=
    "<div><b>Firmware:</b> "
    + String(FIRMWARE_VERSION)
    + "</div>";

  html +=
    "<div><b>Build:</b> "
    + String(FW_BUILD_NAME)
    + "</div>";

  if (WiFi.status() == WL_CONNECTED) {
    html += "<div><b>Wi-Fi:</b> Connected</div>";

    html +=
      "<div><b>ESP32 IP:</b> "
      + WiFi.localIP().toString()
      + "</div>";
  } else {
    html += "<div><b>Wi-Fi:</b> Not connected</div>";
  }

  html += "</div>";

  html +=
    "<div "
    "id='page_error' "
    "class='error' "
    "style='display:none;'>"
    "</div>";

  html +=
    "<form "
    "action='/provision' "
    "method='POST' "
    "id='provision_form'>";

  // =========================================================
  // INSTALLER-VISIBLE PROFILE SELECTION
  // =========================================================

  html += "<label>Sensor Profile:</label>";

  html +=
    "<select "
    "name='profile_code' "
    "id='profile_code' "
    "required>"
    "</select>";

  html +=
    "<div "
    "id='profile_info' "
    "class='profile-info'>"
    "</div>";

  // =========================================================
  // AUTOMATIC PROFILE VALUES
  // =========================================================

  html +=
    "<input "
    "type='hidden' "
    "name='profile_id' "
    "id='profile_id'>";

  html +=
    "<input "
    "type='hidden' "
    "name='profile_version' "
    "id='profile_version'>";

  html +=
    "<input "
    "type='hidden' "
    "name='payload_version' "
    "id='payload_version'>";

  html +=
    "<input "
    "type='hidden' "
    "name='payload_encoder_key' "
    "id='payload_encoder_key'>";

  html +=
    "<input "
    "type='hidden' "
    "name='sensor_module_key' "
    "id='sensor_module_key'>";

  html +=
    "<input "
    "type='hidden' "
    "name='sensor_configuration_json' "
    "id='sensor_configuration_json'>";

  html +=
    "<input "
    "type='hidden' "
    "name='uplink_interval_seconds' "
    "id='uplink_interval_seconds'>";

  html +=
    "<input "
    "type='hidden' "
    "name='node_type' "
    "id='node_type'>";

  html +=
    "<input "
    "type='hidden' "
    "name='firmware_version' "
    "id='firmware_version' "
    "value='"
    + String(FIRMWARE_VERSION)
    + "'>";

  // =========================================================
  // LOCATION
  // =========================================================

  html += "<label>Building:</label>";

  html +=
    "<select "
    "name='building' "
    "id='building' "
    "required>"
    "</select>";

  html += "<label>Floor:</label>";

  html +=
    "<select "
    "name='floor' "
    "id='floor' "
    "required>"
    "</select>";

  html += "<label>Room:</label>";

  html +=
    "<select "
    "name='room' "
    "id='room' "
    "required>"
    "</select>";

  html +=
    "<input "
    "type='hidden' "
    "name='room_id' "
    "id='room_id'>";

  // =========================================================
  // LABEL
  // =========================================================

  html += "<label>Device Label:</label>";

  html +=
    "<input "
    "type='text' "
    "name='label' "
    "id='label' "
    "value='"
    + deviceLabel
    + "' "
    "required>";

  html +=
    "<input "
    "type='submit' "
    "value='Provision Device'>";

  html += "</form>";

  html +=
    "<p class='small'>"
    "The installer selects only the sensor profile and location. "
    "The page automatically prepares the profile ID, profile "
    "version, payload version, node type, room ID and firmware "
    "version."
    "</p>";

  html += "</div>";

  // =========================================================
  // JAVASCRIPT
  // =========================================================

  html += "<script>";

  html +=
    "const options=JSON.parse(`"
    + optionsJson
    + "`);";


  html +=
    "const firmwareModules="
    + SensorRegistry::compiledModuleKeysJson()
    + ";";

  html +=
    "const firmwareEncoders="
    + PayloadRegistry::compiledEncoderKeysJson()
    + ";";

  html +=
    "const profileSelect="
    "document.getElementById('profile_code');";

  html +=
    "const profileInfo="
    "document.getElementById('profile_info');";

  html +=
    "const buildingSelect="
    "document.getElementById('building');";

  html +=
    "const floorSelect="
    "document.getElementById('floor');";

  html +=
    "const roomSelect="
    "document.getElementById('room');";

  html +=
    "const pageError="
    "document.getElementById('page_error');";

  html +=
    "function esc(v){"
    "return String(v??'')"
    ".replaceAll('&','&amp;')"
    ".replaceAll('<','&lt;')"
    ".replaceAll('>','&gt;');"
    "}";

  html +=
    "function setError(message){"
    "pageError.textContent=message||'';"
    "pageError.style.display=message?'block':'none';"
    "}";

  html +=
    "function requiredModule(p){"
    "let components=Array.isArray(p.sensor_components)?p.sensor_components:[];"
    "let primary=components.find(s=>s.required!==false)||components[0]||null;"
    "return primary&&primary.firmware_module?String(primary.firmware_module.module_key||''):'';"
    "}";

  html +=
    "function profileSupported(p){"
    "let encoder=String(p.payload_encoder_key||'');"
    "let moduleKey=requiredModule(p);"
    "return firmwareEncoders.includes(encoder)&&"
    "(!moduleKey||firmwareModules.includes(moduleKey));"
    "}";

  html +=
    "function profiles(){"
    "let all=Array.isArray(options.profiles)?options.profiles:[];"
    "return all.filter(profileSupported);"
    "}";

  html +=
    "function selectedProfile(){"
    "return profiles().find("
    "p=>String(p.profile_code)===profileSelect.value"
    ")||null;"
    "}";

  // =========================================================
  // PROFILE DROPDOWN
  // =========================================================

  html +=
    "function fillProfiles(){"
    "profileSelect.innerHTML='';"

    "profiles().forEach(p=>{"
    "let o=document.createElement('option');"
    "o.value=p.profile_code;"
    "o.textContent=p.profile_name+' (v'+p.profile_version+')';"
    "profileSelect.appendChild(o);"
    "});"

    "if(!profiles().length){"
    "let o=document.createElement('option');"
    "o.value='';"
    "o.textContent='No active sensor profiles available';"
    "profileSelect.appendChild(o);"
    "profileSelect.disabled=true;"
    "setError("
    "'No active sensor profiles were returned by the backend.'"
    ");"
    "}"

    "updateProfile();"
    "}";

  // =========================================================
  // PROFILE INFORMATION AND HIDDEN VALUES
  // =========================================================

  html +=
    "function updateProfile(){"
    "let p=selectedProfile();"

    "if(!p){"
    "profileInfo.style.display='none';"
    "document.getElementById('profile_id').value='';"
    "document.getElementById('node_type').value='';"
    "document.getElementById('sensor_module_key').value='';"
    "document.getElementById('sensor_configuration_json').value='{}';"
    "return;"
    "}"

    "document.getElementById('profile_id').value="
    "p.profile_id??'';"

    "document.getElementById('profile_version').value="
    "p.profile_version??1;"

    "document.getElementById('payload_version').value="
    "p.payload_version??1;"

    "document.getElementById('payload_encoder_key').value="
    "p.payload_encoder_key??'';"


    "let components=Array.isArray(p.sensor_components)?p.sensor_components:[];"
    "let primary=components.find(s=>s.required!==false)||components[0]||null;"
    "let moduleKey=primary&&primary.firmware_module?primary.firmware_module.module_key||'':'';"
    "let sensorConfig=primary&&primary.configuration?primary.configuration:{};"
    "document.getElementById('sensor_module_key').value=moduleKey;"
    "document.getElementById('sensor_configuration_json').value=JSON.stringify(sensorConfig);"

    "document.getElementById("
    "'uplink_interval_seconds'"
    ").value=p.uplink_interval_seconds??60;"

    "document.getElementById('node_type').value="
    "p.node_type??'';"

    "let fields=(p.telemetry_fields||[])"
    ".map(f=>f.label+(f.unit?' ('+f.unit+')':''))"
    ".join(', ');"

    "let sensors=(p.sensor_components||[])"
    ".map(s=>s.model)"
    ".join(', ');"

    "profileInfo.innerHTML="
    "'<div class=\"profile-title\">'"
    "+esc(p.profile_name)"
    "+'</div>'"
    "+'<div>'+esc(p.description||'')+'</div>'"
    "+'<div class=\"muted\"><b>Profile code:</b> '"
    "+esc(p.profile_code)"
    "+' · <b>Node type:</b> '"
    "+esc(p.node_type)"
    "+' · <b>Interval:</b> '"
    "+esc(p.uplink_interval_seconds)"
    "+' seconds</div>'"
    "+'<div class=\"muted\"><b>Sensor:</b> '"
    "+esc(sensors||'Not specified')"
    "+'</div>'"
    "+'<div class=\"muted\"><b>Measures:</b> '"
    "+esc(fields||'Not specified')"
    "+'</div>';"

    "profileInfo.style.display='block';"
    "}";

  // =========================================================
  // BUILDING, FLOOR AND ROOM DROPDOWNS
  // =========================================================

  html +=
    "function fillBuildings(){"
    "buildingSelect.innerHTML='';"

    "Object.keys(options.buildings||{}).forEach(b=>{"
    "let o=document.createElement('option');"
    "o.value=b;"
    "o.textContent=b;"
    "buildingSelect.appendChild(o);"
    "});"

    "if(!buildingSelect.options.length){"
    "let o=document.createElement('option');"
    "o.value='';"
    "o.textContent='No buildings available';"
    "buildingSelect.appendChild(o);"
    "buildingSelect.disabled=true;"

    "setError("
    "'No provisionable rooms were returned. "
    "Create the building, floor and room first.'"
    ");"
    "}"

    "fillFloors();"
    "}";

  html +=
    "function fillFloors(){"
    "floorSelect.innerHTML='';"

    "let floors="
    "(options.buildings||{})[buildingSelect.value]||{};"

    "Object.keys(floors).forEach(f=>{"
    "let o=document.createElement('option');"
    "o.value=f;"
    "o.textContent=f;"
    "floorSelect.appendChild(o);"
    "});"

    "fillRooms();"
    "}";

  html +=
    "function fillRooms(){"
    "roomSelect.innerHTML='';"

    "let floors="
    "(options.buildings||{})[buildingSelect.value]||{};"

    "let rooms=floors[floorSelect.value]||{};"

    "Object.keys(rooms).forEach(r=>{"
    "let info=rooms[r]||{};"
    "let o=document.createElement('option');"
    "o.value=r;"
    "o.textContent=r;"
    "o.dataset.roomId=info.room_id??'';"
    "roomSelect.appendChild(o);"
    "});"

    "updateRoomId();"
    "}";

  html +=
    "function updateRoomId(){"
    "let selected="
    "roomSelect.options[roomSelect.selectedIndex];"

    "document.getElementById('room_id').value="
    "selected?(selected.dataset.roomId||''):'';"
    "}";

  // =========================================================
  // EVENTS
  // =========================================================

  html +=
    "profileSelect.addEventListener("
    "'change',"
    "updateProfile"
    ");";

  html +=
    "buildingSelect.addEventListener("
    "'change',"
    "fillFloors"
    ");";

  html +=
    "floorSelect.addEventListener("
    "'change',"
    "fillRooms"
    ");";

  html +=
    "roomSelect.addEventListener("
    "'change',"
    "updateRoomId"
    ");";

  html +=
    "document.getElementById('provision_form')"
    ".addEventListener('submit',e=>{"

    "if("
    "!document.getElementById('profile_id').value"
    "||"
    "!document.getElementById('sensor_module_key').value"
    "||"
    "!document.getElementById('room_id').value"
    "){"

    "e.preventDefault();"

    "setError("
    "'Select a valid sensor profile and room "
    "before provisioning.'"
    ");"
    "}"
    "});";

  html += "fillProfiles();";
  html += "fillBuildings();";

  html += "</script>";
  html += "</body></html>";

  server.send(200, "text/html", html);
}

void handleProvision() {
  // =========================================================
  // 1. VERIFY ALL REQUIRED FORM FIELDS
  // =========================================================

  if (
    !server.hasArg("profile_id") ||
    !server.hasArg("profile_code") ||
    !server.hasArg("profile_version") ||
    !server.hasArg("payload_version") ||
    !server.hasArg("payload_encoder_key") ||
    !server.hasArg("sensor_module_key") ||
    !server.hasArg("sensor_configuration_json") ||
    !server.hasArg("uplink_interval_seconds") ||
    !server.hasArg("node_type") ||
    !server.hasArg("firmware_version") ||
    !server.hasArg("building") ||
    !server.hasArg("floor") ||
    !server.hasArg("room") ||
    !server.hasArg("room_id") ||
    !server.hasArg("label")
  ) {
    server.send(
      400,
      "text/html",
      "<html><body>"
      "<h3>Missing provisioning fields</h3>"
      "<p>Select a sensor profile and room.</p>"
      "</body></html>"
    );

    Serial.println(
      "Provision failed: missing profile or location fields"
    );

    return;
  }

  // =========================================================
  // 2. VERIFY WI-FI
  // =========================================================

  if (WiFi.status() != WL_CONNECTED) {
    server.send(
      500,
      "text/html",
      "<html><body>"
      "<h3>ESP32 is not connected to Wi-Fi.</h3>"
      "</body></html>"
    );

    Serial.println(
      "Provision failed: ESP32 is not connected to WiFi"
    );

    return;
  }

  // =========================================================
  // 3. READ SELECTED PROFILE
  // =========================================================

  selectedProfileId = server.arg(
    "profile_id"
  ).toInt();

  selectedProfileCode = server.arg(
    "profile_code"
  );

  selectedProfileVersion = server.arg(
    "profile_version"
  ).toInt();

  selectedPayloadVersion = server.arg(
    "payload_version"
  ).toInt();

  selectedPayloadEncoderKey = server.arg(
    "payload_encoder_key"
  );

  selectedSensorModuleKey = server.arg(
    "sensor_module_key"
  );

  selectedSensorConfigurationJson = server.arg(
    "sensor_configuration_json"
  );

  selectedUplinkIntervalSeconds = server.arg(
    "uplink_interval_seconds"
  ).toInt();

  nodeType = server.arg(
    "node_type"
  );

  // The firmware uses its compiled constant instead of
  // trusting a browser-submitted version string.
  String currentFirmwareVersion = String(
    FIRMWARE_VERSION
  );

  // =========================================================
  // 4. READ LOCATION
  // =========================================================

  buildingName = server.arg(
    "building"
  );

  floorName = server.arg(
    "floor"
  );

  roomName = server.arg(
    "room"
  );

  selectedRoomId = server.arg(
    "room_id"
  ).toInt();

  deviceLabel = server.arg(
    "label"
  );

  // =========================================================
  // 5. VALIDATE VALUES
  // =========================================================

  selectedProfileCode.trim();
  selectedPayloadEncoderKey.trim();
  selectedSensorModuleKey.trim();
  nodeType.trim();
  buildingName.trim();
  floorName.trim();
  roomName.trim();
  deviceLabel.trim();

  if (
    selectedProfileId <= 0 ||
    selectedProfileCode.length() == 0 ||
    selectedProfileVersion <= 0 ||
    selectedPayloadVersion <= 0 ||
    selectedPayloadEncoderKey.length() == 0 ||
    selectedSensorModuleKey.length() == 0 ||
    selectedUplinkIntervalSeconds <= 0 ||
    nodeType.length() == 0 ||
    selectedRoomId <= 0 ||
    buildingName.length() == 0 ||
    floorName.length() == 0 ||
    roomName.length() == 0 ||
    deviceLabel.length() == 0
  ) {
    server.send(
      400,
      "text/html",
      "<html><body>"
      "<h3>Invalid profile or room selection</h3>"
      "<p>Return to the configuration page and select "
      "a valid profile and room.</p>"
      "</body></html>"
    );

    Serial.println(
      "Provision failed: invalid profile or location values"
    );

    return;
  }


  if (
    !SensorRegistry::supportsProfile(
      selectedSensorModuleKey,
      selectedProfileCode,
      selectedPayloadEncoderKey
    ) ||
    !PayloadRegistry::supportsEncoder(selectedPayloadEncoderKey)
  ) {
    server.send(
      400,
      "text/html",
      "<html><body><h3>Firmware profile incompatibility</h3>"
      "<p>The selected sensor module or payload encoder is not compiled "
      "into this firmware build.</p></body></html>"
    );
    Serial.println("Provision failed: profile is not supported by this firmware build");
    return;
  }

  // =========================================================
  // 6. CREATE BACKEND REQUEST
  // =========================================================

  HTTPClient http;

  http.begin(
    provisionServer
  );

  http.addHeader(
    "Content-Type",
    "application/json"
  );

  DynamicJsonDocument reqDoc(2048);

  reqDoc["chip_mac"] = chipMac;

  reqDoc["profile_id"] = selectedProfileId;

  reqDoc["profile_code"] = selectedProfileCode;

  reqDoc["profile_version"] = (
    selectedProfileVersion
  );

  reqDoc["payload_version"] = (
    selectedPayloadVersion
  );

  reqDoc["payload_encoder_key"] = (
    selectedPayloadEncoderKey
  );

  reqDoc["uplink_interval_seconds"] = (
    selectedUplinkIntervalSeconds
  );

  reqDoc["firmware_version"] = (
    currentFirmwareVersion
  );

  // This value is included for legacy compatibility.
  // The backend will later verify it against the profile.
  reqDoc["node_type"] = nodeType;

  reqDoc["building"] = buildingName;
  reqDoc["floor"] = floorName;
  reqDoc["room"] = roomName;
  reqDoc["room_id"] = selectedRoomId;
  reqDoc["label"] = deviceLabel;

  String json;

  serializeJson(
    reqDoc,
    json
  );

  Serial.println(
    "Sending profile-driven provisioning request..."
  );

  Serial.println(json);

  // =========================================================
  // 7. SEND REQUEST
  // =========================================================

  int httpCode = http.POST(
    json
  );

  String response = http.getString();

  Serial.print("HTTP code: ");
  Serial.println(httpCode);

  Serial.println("Response:");
  Serial.println(response);

  // =========================================================
  // 8. PROCESS SUCCESSFUL RESPONSE
  // =========================================================

  if (httpCode == 200) {
    DynamicJsonDocument doc(4096);

    DeserializationError error = deserializeJson(
      doc,
      response
    );

    if (!error) {
      String status = doc["status"] | "";

      String device_id = doc["device_id"] | "";
      String dev_eui = doc["dev_eui"] | "";
      String join_eui = doc["join_eui"] | "";
      String app_key = doc["app_key"] | "";

      String res_node_type = (
        doc["node_type"] | nodeType
      );

      int res_profile_id = (
        doc["profile_id"] | selectedProfileId
      );

      String res_profile_code = (
        doc["profile_code"] |
        selectedProfileCode
      );

      int res_profile_version = (
        doc["profile_version"] |
        selectedProfileVersion
      );

      int res_payload_version = (
        doc["payload_version"] |
        selectedPayloadVersion
      );

      String res_payload_encoder_key = (
        doc["payload_encoder_key"] |
        selectedPayloadEncoderKey
      );

      int res_uplink_interval_seconds = (
        doc["uplink_interval_seconds"] |
        selectedUplinkIntervalSeconds
      );

      String res_firmware_version = (
        doc["firmware_version"] |
        currentFirmwareVersion
      );

      String res_configuration_status = (
        doc["configuration_status"] |
        "pending_backend_confirmation"
      );

      String res_configuration_checksum = (
        doc["configuration_checksum"] | ""
      );

      String res_building = (
        doc["building"] | buildingName
      );

      String res_floor = (
        doc["floor"] | floorName
      );

      String res_room = (
        doc["room"] | roomName
      );

      int res_room_id = (
        doc["room_id"] | selectedRoomId
      );

      String res_label = (
        doc["label"] | deviceLabel
      );

      // =====================================================
      // 9. SAVE BACKEND-CONFIRMED VALUES
      // =====================================================

      saveProvisioningData(
        status,
        device_id,
        dev_eui,
        join_eui,
        app_key,

        res_node_type,

        res_profile_id,
        res_profile_code,
        res_profile_version,
        res_payload_version,
        res_payload_encoder_key,
        selectedSensorModuleKey,
        selectedSensorConfigurationJson,
        res_uplink_interval_seconds,
        res_firmware_version,

        res_configuration_status,
        res_configuration_checksum,

        res_building,
        res_floor,
        res_room,
        res_room_id,
        res_label
      );

      // Reload the backend-confirmed runtime configuration so the
      // selected driver, encoder and interval become active now.
      hasSavedRuntimeConfig = (
        loadSavedRuntimeConfiguration()
      );

      SensorRegistry::select(
        selectedSensorModuleKey,
        selectedProfileCode,
        selectedPayloadEncoderKey,
        selectedSensorConfigurationJson
      );

      Serial.println(
        "Parsed provisioning response:"
      );

      Serial.print("status: ");
      Serial.println(status);

      Serial.print("device_id: ");
      Serial.println(device_id);

      Serial.print("dev_eui: ");
      Serial.println(dev_eui);

      Serial.print("join_eui: ");
      Serial.println(join_eui);

      Serial.print("profile_id: ");
      Serial.println(res_profile_id);

      Serial.print("profile_code: ");
      Serial.println(res_profile_code);

      Serial.print("profile_version: ");
      Serial.println(res_profile_version);

      Serial.print("payload_version: ");
      Serial.println(res_payload_version);

      Serial.print("payload_encoder_key: ");
      Serial.println(
        res_payload_encoder_key
      );

      Serial.print("sensor_module_key: ");
      Serial.println(selectedSensorModuleKey);

      Serial.print("sensor_configuration: ");
      Serial.println(selectedSensorConfigurationJson);

      Serial.print("uplink_interval_seconds: ");
      Serial.println(
        res_uplink_interval_seconds
      );

      Serial.print("firmware_version: ");
      Serial.println(
        res_firmware_version
      );

      Serial.print("configuration_status: ");
      Serial.println(
        res_configuration_status
      );

      Serial.print("configuration_checksum: ");
      Serial.println(
        res_configuration_checksum
      );

      Serial.print("node_type: ");
      Serial.println(res_node_type);

      Serial.print("building: ");
      Serial.println(res_building);

      Serial.print("floor: ");
      Serial.println(res_floor);

      Serial.print("room: ");
      Serial.println(res_room);

      Serial.print("room_id: ");
      Serial.println(res_room_id);

      Serial.print("label: ");
      Serial.println(res_label);

      // =====================================================
      // 10. RELOAD LORAWAN CREDENTIALS
      // =====================================================

      hasSavedLoRaWANCreds = (
        loadSavedLoRaWANCredentials()
      );

      // =====================================================
      // 11. SUCCESS PAGE
      // =====================================================

      String okPage =
        "<html><body>"
        "<h3>Provisioning complete</h3>";

      okPage +=
        "<p><b>Status:</b> "
        + status
        + "</p>";

      okPage +=
        "<p><b>Device ID:</b> "
        + device_id
        + "</p>";

      okPage +=
        "<p><b>Sensor profile:</b> "
        + res_profile_code
        + "</p>";

      okPage +=
        "<p><b>Profile version:</b> "
        + String(res_profile_version)
        + "</p>";

      okPage +=
        "<p><b>Node type:</b> "
        + res_node_type
        + "</p>";

      okPage +=
        "<p><b>Building:</b> "
        + res_building
        + "</p>";

      okPage +=
        "<p><b>Floor:</b> "
        + res_floor
        + "</p>";

      okPage +=
        "<p><b>Room:</b> "
        + res_room
        + "</p>";

      okPage +=
        "<p><b>Room ID:</b> "
        + String(res_room_id)
        + "</p>";

      okPage +=
        "<p><b>Label:</b> "
        + res_label
        + "</p>";

      okPage +=
        "<p>Configuration saved in flash memory.</p>";

      okPage +=
        "<p>Starting LoRaWAN join...</p>";

      okPage +=
        "</body></html>";

      server.send(
        200,
        "text/html",
        okPage
      );

      delay(1000);

      stopConfigPortal();

      delay(1000);

      if (hasSavedLoRaWANCreds) {
        startLoRaWANJoin();
      }

    } else {
      Serial.print(
        "Provision response JSON parse error: "
      );

      Serial.println(
        error.c_str()
      );

      server.send(
        500,
        "text/html",
        "<html><body>"
        "<h3>Provision response JSON parse error</h3>"
        "</body></html>"
      );
    }

  } else {
    String errPage =
      "<html><body>"
      "<h3>Provision request failed</h3>";

    errPage +=
      "<p><b>HTTP code:</b> "
      + String(httpCode)
      + "</p>";

    errPage +=
      "<p><b>Response:</b> "
      + response
      + "</p>";

    errPage +=
      "<p>Check the backend and Serial Monitor.</p>";

    errPage +=
      "</body></html>";

    server.send(
      500,
      "text/html",
      errPage
    );
  }

  http.end();
}

void startConfigPortal() {
  WiFi.softAP(apSSID, apPassword);

  IPAddress apIP = WiFi.softAPIP();
  Serial.print("AP IP: ");
  Serial.println(apIP);

  dnsServer.start(DNS_PORT, "*", apIP);

  server.on("/", HTTP_GET, handleRoot);
  server.on("/generate_204", HTTP_GET, handleRoot);
  server.on("/fwlink", HTTP_GET, handleRoot);
  server.on("/hotspot-detect.html", HTTP_GET, handleRoot);
  server.on("/provision", HTTP_POST, handleProvision);
  server.onNotFound(handleRoot);

  server.begin();
  configStartTime = millis();

  Serial.println("Provisioning portal ready");
}

void setup() {
  Serial.begin(115200);
  delay(2000);

  Serial.print("Firmware build preset: ");
  Serial.println(FW_BUILD_NAME);
  Serial.print("Compiled sensor modules: ");
  Serial.println(SensorRegistry::compiledModuleKeysJson());
  Serial.print("Compiled payload encoders: ");
  Serial.println(PayloadRegistry::compiledEncoderKeysJson());

  chipMac = getChipMac();
  Serial.print("Chip MAC: ");
  Serial.println(chipMac);

  Wire.begin(21, 22);

  printSavedProvisioningData();

  hasSavedRuntimeConfig = (
    loadSavedRuntimeConfiguration()
  );

  // Select only the driver compiled into this small firmware build.
  SensorRegistry::select(
    selectedSensorModuleKey,
    selectedProfileCode,
    selectedPayloadEncoderKey,
    selectedSensorConfigurationJson
  );

  hasSavedLoRaWANCreds = (
    loadSavedLoRaWANCredentials()
  );

  if (
    hasSavedLoRaWANCreds
    ) {
    Serial.println("Saved credentials found in flash");
    configMode = false;
    startLoRaWANJoin();
  } else {
    Serial.println("No valid saved LoRaWAN credentials found yet");
    connectToWiFi();
    startConfigPortal();
  }
}

void loop() {
  if (configMode) {
    dnsServer.processNextRequest();
    server.handleClient();

    if (millis() - configStartTime > configWindow) {
      stopConfigPortal();
    }
  }

  if (lmicStarted) {
    os_runloop_once();
  }
}