#pragma once

// =============================================================
// SMART BUILDING FIRMWARE BUILD PRESETS
//
// Select ONE small firmware build. The stable provisioning and
// LoRaWAN core is shared by every preset, while only the selected
// sensor drivers and payload encoders are compiled.
// =============================================================

#define FW_PRESET_BME688_ONLY       1
#define FW_PRESET_SHT31_ONLY        2
#define FW_PRESET_ENVIRONMENT_ALL   3
#define FW_PRESET_LEGACY_MULTI      4

// Change only this line when producing another firmware build.
#define FW_BUILD_PRESET FW_PRESET_BME688_ONLY

// Production diagnostics. Set to 0 after deployment to remove
// most module-specific Serial output.
#define FW_SENSOR_DEBUG 1

#if FW_BUILD_PRESET == FW_PRESET_BME688_ONLY
  #define FW_BUILD_NAME "BME688_ONLY"
  #define FW_ENABLE_SENSOR_BME688 1
  #define FW_ENABLE_SENSOR_SHT31  0
  #define FW_ENABLE_ENCODER_BME688_V1     1
  #define FW_ENABLE_ENCODER_ENVIRONMENT_V1 0
  #define FW_ENABLE_ENCODER_MULTI_V1       0

#elif FW_BUILD_PRESET == FW_PRESET_SHT31_ONLY
  #define FW_BUILD_NAME "SHT31_ONLY"
  #define FW_ENABLE_SENSOR_BME688 0
  #define FW_ENABLE_SENSOR_SHT31  1
  #define FW_ENABLE_ENCODER_BME688_V1      0
  #define FW_ENABLE_ENCODER_ENVIRONMENT_V1 1
  #define FW_ENABLE_ENCODER_MULTI_V1       0

#elif FW_BUILD_PRESET == FW_PRESET_ENVIRONMENT_ALL
  #define FW_BUILD_NAME "ENVIRONMENT_ALL"
  #define FW_ENABLE_SENSOR_BME688 1
  #define FW_ENABLE_SENSOR_SHT31  1
  #define FW_ENABLE_ENCODER_BME688_V1      1
  #define FW_ENABLE_ENCODER_ENVIRONMENT_V1 1
  #define FW_ENABLE_ENCODER_MULTI_V1       0

#elif FW_BUILD_PRESET == FW_PRESET_LEGACY_MULTI
  #define FW_BUILD_NAME "LEGACY_MULTI"
  #define FW_ENABLE_SENSOR_BME688 0
  #define FW_ENABLE_SENSOR_SHT31  1
  #define FW_ENABLE_ENCODER_BME688_V1      0
  #define FW_ENABLE_ENCODER_ENVIRONMENT_V1 1
  #define FW_ENABLE_ENCODER_MULTI_V1       1

#else
  #error "Invalid FW_BUILD_PRESET in BuildConfig.h"
#endif
