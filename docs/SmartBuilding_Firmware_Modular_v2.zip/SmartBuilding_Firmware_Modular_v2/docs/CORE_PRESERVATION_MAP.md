# Core Preserved from `lilygocodefinalCopy.ino`

The following working functions remain in the main reusable core:

- Wi-Fi AP/STA setup and captive provisioning portal
- `/provision-options` retrieval
- Profile, building, floor and room selection
- `/provision` backend request
- Preferences/NVS credential and runtime storage
- OTAA DevEUI, JoinEUI and AppKey callbacks
- LMIC initialization, joining, events and uplink scheduling
- Backend-confirmed profile and location storage
- `setup()` and `loop()` control flow

The following sensor-specific parts were extracted from the original file:

- SHT30/SHT31 initialization and readings
- BME688 initialization and readings
- Environment, BME688 and legacy multi payload encoding
- Driver selection and payload-encoder selection

The extracted code is now compiled conditionally through `BuildConfig.h`.
