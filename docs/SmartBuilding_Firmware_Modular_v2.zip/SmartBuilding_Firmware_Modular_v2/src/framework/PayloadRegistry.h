#pragma once

#include <Arduino.h>
#include "TelemetryTypes.h"

namespace PayloadRegistry {

bool encode(
  const String& payloadEncoderKey,
  const SensorReadingSet& readings,
  PayloadBuffer& payload
);

bool supportsEncoder(const String& payloadEncoderKey);
String compiledEncoderKeysJson();
void printHex(const PayloadBuffer& payload);

}  // namespace PayloadRegistry
