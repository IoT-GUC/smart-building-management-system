#pragma once

#include <Arduino.h>
#include <cstring>

constexpr uint8_t MAX_SENSOR_READINGS = 12;
constexpr uint8_t MAX_LORAWAN_PAYLOAD_BYTES = 32;

enum SensorReadingType {
  SENSOR_READING_NUMBER,
  SENSOR_READING_BOOLEAN
};

struct SensorReading {
  const char* fieldKey = nullptr;
  SensorReadingType type = SENSOR_READING_NUMBER;
  float numberValue = 0.0f;
  bool booleanValue = false;
  bool valid = false;
};

struct SensorReadingSet {
  SensorReading values[MAX_SENSOR_READINGS];
  uint8_t count = 0;

  void clear() {
    count = 0;
    for (uint8_t index = 0; index < MAX_SENSOR_READINGS; index++) {
      values[index] = SensorReading{};
    }
  }

  int findIndex(const char* fieldKey) const {
    if (fieldKey == nullptr) return -1;
    for (uint8_t index = 0; index < count; index++) {
      if (values[index].fieldKey != nullptr &&
          std::strcmp(values[index].fieldKey, fieldKey) == 0) {
        return index;
      }
    }
    return -1;
  }

  bool addNumber(const char* fieldKey, float value) {
    if (fieldKey == nullptr) return false;
    int existing = findIndex(fieldKey);
    if (existing < 0 && count >= MAX_SENSOR_READINGS) return false;
    uint8_t target = existing >= 0 ? static_cast<uint8_t>(existing) : count++;
    values[target].fieldKey = fieldKey;
    values[target].type = SENSOR_READING_NUMBER;
    values[target].numberValue = value;
    values[target].booleanValue = false;
    values[target].valid = true;
    return true;
  }

  bool addBoolean(const char* fieldKey, bool value) {
    if (fieldKey == nullptr) return false;
    int existing = findIndex(fieldKey);
    if (existing < 0 && count >= MAX_SENSOR_READINGS) return false;
    uint8_t target = existing >= 0 ? static_cast<uint8_t>(existing) : count++;
    values[target].fieldKey = fieldKey;
    values[target].type = SENSOR_READING_BOOLEAN;
    values[target].numberValue = 0.0f;
    values[target].booleanValue = value;
    values[target].valid = true;
    return true;
  }

  bool getNumber(const char* fieldKey, float& value) const {
    int index = findIndex(fieldKey);
    if (index < 0 || !values[index].valid ||
        values[index].type != SENSOR_READING_NUMBER) return false;
    value = values[index].numberValue;
    return true;
  }

  bool getBoolean(const char* fieldKey, bool& value) const {
    int index = findIndex(fieldKey);
    if (index < 0 || !values[index].valid ||
        values[index].type != SENSOR_READING_BOOLEAN) return false;
    value = values[index].booleanValue;
    return true;
  }
};

struct PayloadBuffer {
  uint8_t bytes[MAX_LORAWAN_PAYLOAD_BYTES] = {0};
  uint8_t length = 0;

  void clear() {
    length = 0;
    for (uint8_t& value : bytes) value = 0;
  }

  bool hasSpace(uint8_t requiredBytes) const {
    return length + requiredBytes <= MAX_LORAWAN_PAYLOAD_BYTES;
  }

  bool appendUint8(uint8_t value) {
    if (!hasSpace(1)) return false;
    bytes[length++] = value;
    return true;
  }

  bool appendUint16BE(uint16_t value) {
    if (!hasSpace(2)) return false;
    bytes[length++] = static_cast<uint8_t>((value >> 8) & 0xFF);
    bytes[length++] = static_cast<uint8_t>(value & 0xFF);
    return true;
  }

  bool appendInt16BE(int16_t value) {
    return appendUint16BE(static_cast<uint16_t>(value));
  }
};
