#pragma once

#include <Arduino.h>
#include "TelemetryTypes.h"

namespace SensorRegistry {

bool select(
  const String& moduleKey,
  const String& profileCode,
  const String& payloadEncoderKey,
  const String& configurationJson
);

bool read(SensorReadingSet& readings);
bool supportsModule(const String& moduleKey);
bool supportsProfile(const String& moduleKey, const String& profileCode, const String& encoderKey);
String compiledModuleKeysJson();
const char* activeModuleKey();

}  // namespace SensorRegistry
