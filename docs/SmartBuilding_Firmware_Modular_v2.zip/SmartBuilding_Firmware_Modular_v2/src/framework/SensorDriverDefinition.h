#pragma once

#include <Arduino.h>
#include "TelemetryTypes.h"

using SensorBeginFunction = bool (*)(const String& configurationJson);
using SensorReadFunction = bool (*)(SensorReadingSet& readings);

struct SensorDriverDefinition {
  const char* moduleKey;
  const char* displayName;
  SensorBeginFunction beginFunction;
  SensorReadFunction readFunction;
};
