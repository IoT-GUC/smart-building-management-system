#include "../../BuildConfig.h"
#include "SensorRegistry.h"
#include "SensorDriverDefinition.h"
#include "../sensors/SHT31SensorModule.h"
#include "../sensors/BME688SensorModule.h"

namespace {
const SensorDriverDefinition* activeDriver = nullptr;
String activeConfiguration;

const SensorDriverDefinition* resolveByModule(const String& moduleKey) {
#if FW_ENABLE_SENSOR_BME688
  if (moduleKey == "bme688_i2c") return &getBME688SensorDriver();
#endif
#if FW_ENABLE_SENSOR_SHT31
  if (moduleKey == "sht31_i2c") return &getSHT31SensorDriver();
#endif
  return nullptr;
}

const SensorDriverDefinition* resolveLegacyProfile(
  const String& profileCode,
  const String& encoderKey
) {
#if FW_ENABLE_SENSOR_BME688
  if (profileCode == "AIR_BME688_V1" ||
      profileCode == "BME688_V1" ||
      (profileCode.length() == 0 && encoderKey == "bme688_v1")) {
    return &getBME688SensorDriver();
  }
#endif

#if FW_ENABLE_SENSOR_SHT31
  if (profileCode == "ENV_SHT31_V1" ||
      profileCode == "MULTI_LEGACY_V1" ||
      (profileCode.length() == 0 &&
       (encoderKey == "environment_v1" || encoderKey == "multi_v1"))) {
    return &getSHT31SensorDriver();
  }
#endif

  return nullptr;
}
}

namespace SensorRegistry {

bool select(
  const String& moduleKey,
  const String& profileCode,
  const String& payloadEncoderKey,
  const String& configurationJson
) {
  String normalizedModule = moduleKey;
  String normalizedProfile = profileCode;
  String normalizedEncoder = payloadEncoderKey;
  normalizedModule.trim();
  normalizedProfile.trim();
  normalizedEncoder.trim();

  activeDriver = resolveByModule(normalizedModule);
  if (activeDriver == nullptr) {
    activeDriver = resolveLegacyProfile(normalizedProfile, normalizedEncoder);
  }

  activeConfiguration = configurationJson;

  Serial.println("---- Sensor Driver Selection ----");
  Serial.print("Build preset: "); Serial.println(FW_BUILD_NAME);
  Serial.print("Requested module: "); Serial.println(normalizedModule);
  Serial.print("Profile code: "); Serial.println(normalizedProfile);
  Serial.print("Payload encoder: "); Serial.println(normalizedEncoder);

  if (activeDriver == nullptr) {
    Serial.println("Driver: unsupported by this firmware build");
    Serial.println("---------------------------------");
    return false;
  }

  Serial.print("Driver module: "); Serial.println(activeDriver->moduleKey);
  Serial.print("Driver name: "); Serial.println(activeDriver->displayName);

  bool initialized = activeDriver->beginFunction != nullptr &&
                     activeDriver->beginFunction(activeConfiguration);
  Serial.print("Driver initialization: ");
  Serial.println(initialized ? "successful" : "failed");
  Serial.println("---------------------------------");
  return initialized;
}

bool read(SensorReadingSet& readings) {
  readings.clear();
  if (activeDriver == nullptr || activeDriver->readFunction == nullptr) {
    Serial.println("No active sensor driver");
    return false;
  }

  bool success = activeDriver->readFunction(readings);
  if (!success) {
    Serial.print("Sensor driver read failed: ");
    Serial.println(activeDriver->moduleKey);
  }
  return success;
}

bool supportsModule(const String& moduleKey) {
  String normalized = moduleKey;
  normalized.trim();
  return resolveByModule(normalized) != nullptr;
}

bool supportsProfile(
  const String& moduleKey,
  const String& profileCode,
  const String& encoderKey
) {
  if (moduleKey.length() > 0) return supportsModule(moduleKey);
  return resolveLegacyProfile(profileCode, encoderKey) != nullptr;
}

String compiledModuleKeysJson() {
  String json = "[";
  bool first = true;
#if FW_ENABLE_SENSOR_BME688
  json += "\"bme688_i2c\"";
  first = false;
#endif
#if FW_ENABLE_SENSOR_SHT31
  if (!first) json += ",";
  json += "\"sht31_i2c\"";
#endif
  json += "]";
  return json;
}

const char* activeModuleKey() {
  return activeDriver == nullptr ? "" : activeDriver->moduleKey;
}

}  // namespace SensorRegistry
