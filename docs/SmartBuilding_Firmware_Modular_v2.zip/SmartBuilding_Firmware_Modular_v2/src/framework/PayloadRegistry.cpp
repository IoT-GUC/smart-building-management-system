#include "../../BuildConfig.h"
#include "PayloadRegistry.h"
#include "../payloads/EnvironmentV1Encoder.h"
#include "../payloads/BME688V1Encoder.h"
#include "../payloads/MultiV1Encoder.h"

namespace PayloadRegistry {

bool supportsEncoder(const String& payloadEncoderKey) {
  String key = payloadEncoderKey;
  key.trim();
#if FW_ENABLE_ENCODER_BME688_V1
  if (key == "bme688_v1") return true;
#endif
#if FW_ENABLE_ENCODER_ENVIRONMENT_V1
  if (key == "environment_v1") return true;
#endif
#if FW_ENABLE_ENCODER_MULTI_V1
  if (key == "multi_v1") return true;
#endif
  return false;
}

bool encode(
  const String& payloadEncoderKey,
  const SensorReadingSet& readings,
  PayloadBuffer& payload
) {
  String key = payloadEncoderKey;
  key.trim();

#if FW_ENABLE_ENCODER_BME688_V1
  if (key == "bme688_v1") return encodeBME688V1(readings, payload);
#endif
#if FW_ENABLE_ENCODER_ENVIRONMENT_V1
  if (key == "environment_v1") return encodeEnvironmentV1(readings, payload);
#endif
#if FW_ENABLE_ENCODER_MULTI_V1
  if (key == "multi_v1") return encodeMultiV1(readings, payload);
#endif

  Serial.print("Unsupported payload encoder in this build: ");
  Serial.println(key);
  payload.clear();
  return false;
}

String compiledEncoderKeysJson() {
  String json = "[";
  bool first = true;
#if FW_ENABLE_ENCODER_BME688_V1
  json += "\"bme688_v1\"";
  first = false;
#endif
#if FW_ENABLE_ENCODER_ENVIRONMENT_V1
  if (!first) json += ",";
  json += "\"environment_v1\"";
  first = false;
#endif
#if FW_ENABLE_ENCODER_MULTI_V1
  if (!first) json += ",";
  json += "\"multi_v1\"";
#endif
  json += "]";
  return json;
}

void printHex(const PayloadBuffer& payload) {
  Serial.print("Payload HEX: ");
  for (uint8_t index = 0; index < payload.length; index++) {
    if (payload.bytes[index] < 0x10) Serial.print("0");
    Serial.print(payload.bytes[index], HEX);
  }
  Serial.println();
}

}  // namespace PayloadRegistry
