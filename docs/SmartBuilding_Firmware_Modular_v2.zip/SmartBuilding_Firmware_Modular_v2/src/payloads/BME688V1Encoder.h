#pragma once

#include "../framework/TelemetryTypes.h"

#if FW_ENABLE_ENCODER_BME688_V1
bool encodeBME688V1(const SensorReadingSet& readings, PayloadBuffer& payload);
#endif
