#pragma once

#include <Arduino.h>

inline float clampFloat(float value, float minimumValue, float maximumValue) {
  if (value < minimumValue) return minimumValue;
  if (value > maximumValue) return maximumValue;
  return value;
}

inline uint8_t clampBatteryPercent(float value) {
  return static_cast<uint8_t>(clampFloat(value, 0.0f, 100.0f));
}
