#include "../../BuildConfig.h"
#include "MultiV1Encoder.h"

#if FW_ENABLE_ENCODER_MULTI_V1
#include "EncoderHelpers.h"

bool encodeMultiV1(const SensorReadingSet& readings, PayloadBuffer& payload) {
  payload.clear();
  float temperature = 0.0f;
  float humidity = 0.0f;
  if (!readings.getNumber("temperature", temperature) ||
      !readings.getNumber("humidity", humidity)) {
    Serial.println("multi_v1 missing environment readings");
    return false;
  }

  bool motion = false;
  bool alarm = false;
  float voltage = 230.50f;
  float current = 1.25f;
  float power = 288.0f;
  float battery = 87.0f;

  readings.getBoolean("motion", motion);
  readings.getBoolean("alarm", alarm);
  readings.getNumber("voltage", voltage);
  readings.getNumber("current", current);
  readings.getNumber("power", power);
  readings.getNumber("battery", battery);

  temperature = clampFloat(temperature, -40.0f, 125.0f);
  humidity = clampFloat(humidity, 0.0f, 100.0f);
  voltage = clampFloat(voltage, 0.0f, 500.0f);
  current = clampFloat(current, 0.0f, 100.0f);
  power = clampFloat(power, 0.0f, 6553.5f);

  return payload.appendInt16BE(static_cast<int16_t>(temperature * 100.0f)) &&
         payload.appendUint16BE(static_cast<uint16_t>(humidity * 100.0f)) &&
         payload.appendUint8(motion ? 1 : 0) &&
         payload.appendUint8(alarm ? 1 : 0) &&
         payload.appendUint16BE(static_cast<uint16_t>(voltage * 100.0f)) &&
         payload.appendUint16BE(static_cast<uint16_t>(current * 100.0f)) &&
         payload.appendUint16BE(static_cast<uint16_t>(power * 10.0f)) &&
         payload.appendUint8(clampBatteryPercent(battery)) &&
         payload.length == 13;
}
#endif
