#pragma once

#include "../framework/TelemetryTypes.h"

#if FW_ENABLE_ENCODER_MULTI_V1
bool encodeMultiV1(const SensorReadingSet& readings, PayloadBuffer& payload);
#endif
