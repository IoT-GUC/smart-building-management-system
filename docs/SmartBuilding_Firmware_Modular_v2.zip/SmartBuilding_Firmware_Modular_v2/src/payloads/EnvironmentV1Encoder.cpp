#include "../../BuildConfig.h"
#include "EnvironmentV1Encoder.h"

#if FW_ENABLE_ENCODER_ENVIRONMENT_V1
#include "EncoderHelpers.h"

bool encodeEnvironmentV1(const SensorReadingSet& readings, PayloadBuffer& payload) {
  payload.clear();
  float temperature = 0.0f;
  float humidity = 0.0f;

  if (!readings.getNumber("temperature", temperature) ||
      !readings.getNumber("humidity", humidity)) {
    Serial.println("environment_v1 missing temperature or humidity");
    return false;
  }

  temperature = clampFloat(temperature, -40.0f, 125.0f);
  humidity = clampFloat(humidity, 0.0f, 100.0f);

  int16_t encodedTemperature = static_cast<int16_t>(temperature * 100.0f);
  uint16_t encodedHumidity = static_cast<uint16_t>(humidity * 100.0f);

  return payload.appendInt16BE(encodedTemperature) &&
         payload.appendUint16BE(encodedHumidity) &&
         payload.length == 4;
}
#endif
