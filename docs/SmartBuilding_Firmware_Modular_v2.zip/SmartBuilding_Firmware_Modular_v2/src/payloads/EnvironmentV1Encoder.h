#pragma once

#include "../framework/TelemetryTypes.h"

#if FW_ENABLE_ENCODER_ENVIRONMENT_V1
bool encodeEnvironmentV1(const SensorReadingSet& readings, PayloadBuffer& payload);
#endif
