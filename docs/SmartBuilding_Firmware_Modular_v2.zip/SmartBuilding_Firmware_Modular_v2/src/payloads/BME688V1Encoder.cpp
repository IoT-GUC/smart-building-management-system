#include "../../BuildConfig.h"
#include "BME688V1Encoder.h"

#if FW_ENABLE_ENCODER_BME688_V1
#include "EncoderHelpers.h"

bool encodeBME688V1(const SensorReadingSet& readings, PayloadBuffer& payload) {
  payload.clear();
  float temperature = 0.0f;
  float humidity = 0.0f;
  float pressure = 0.0f;
  float gasResistance = 0.0f;

  if (!readings.getNumber("temperature", temperature) ||
      !readings.getNumber("humidity", humidity) ||
      !readings.getNumber("pressure", pressure) ||
      !readings.getNumber("gas_resistance", gasResistance)) {
    Serial.println("bme688_v1 missing one or more readings");
    return false;
  }

  temperature = clampFloat(temperature, -40.0f, 125.0f);
  humidity = clampFloat(humidity, 0.0f, 100.0f);
  pressure = clampFloat(pressure, 0.0f, 6553.5f);
  gasResistance = clampFloat(gasResistance, 0.0f, 65535.0f);

  int16_t encodedTemperature = static_cast<int16_t>(temperature * 100.0f);
  uint16_t encodedHumidity = static_cast<uint16_t>(humidity * 100.0f);
  uint16_t encodedPressure = static_cast<uint16_t>(pressure * 10.0f);
  uint16_t encodedGas = static_cast<uint16_t>(gasResistance);

  return payload.appendInt16BE(encodedTemperature) &&
         payload.appendUint16BE(encodedHumidity) &&
         payload.appendUint16BE(encodedPressure) &&
         payload.appendUint16BE(encodedGas) &&
         payload.length == 8;
}
#endif
