#include "../../BuildConfig.h"
#include "BME688SensorModule.h"

#if FW_ENABLE_SENSOR_BME688

#include <ArduinoJson.h>
#include <Wire.h>
#include "bme68xLibrary.h"
#include <cmath>

namespace {
Bme68x sensor;
bool found = false;
uint8_t activeAddress = BME68X_I2C_ADDR_HIGH;

uint8_t parseAddress(JsonVariantConst value, uint8_t fallback) {
  if (value.is<unsigned int>()) return static_cast<uint8_t>(value.as<unsigned int>());
  String text = value.as<String>();
  text.trim();
  if (text.length() == 0) return fallback;
  return static_cast<uint8_t>(strtoul(text.c_str(), nullptr, 0));
}

bool beginSensor(const String& configurationJson) {
  found = false;
  uint8_t sdaPin = 21;
  uint8_t sclPin = 22;
  uint8_t address = BME68X_I2C_ADDR_HIGH;

  if (configurationJson.length() > 0) {
    DynamicJsonDocument doc(512);
    if (deserializeJson(doc, configurationJson) == DeserializationError::Ok) {
      sdaPin = doc["sda_pin"] | sdaPin;
      sclPin = doc["scl_pin"] | sclPin;
      address = parseAddress(doc["address"], address);
      address = parseAddress(doc["i2c_address"], address);
    }
  }

  Wire.begin(sdaPin, sclPin);
  activeAddress = address;

#if FW_SENSOR_DEBUG
  Serial.print("Trying BME688 at 0x");
  Serial.println(activeAddress, HEX);
#endif

  sensor.begin(activeAddress, Wire);
  int8_t status = sensor.checkStatus();
  if (status == BME68X_ERROR) {
#if FW_SENSOR_DEBUG
    Serial.print("BME688 initialization error: ");
    Serial.println(sensor.statusString());
#endif
    return false;
  }

  if (status == BME68X_WARNING) {
#if FW_SENSOR_DEBUG
    Serial.print("BME688 initialization warning: ");
    Serial.println(sensor.statusString());
#endif
  }

  sensor.setTPH();
  sensor.setHeaterProf(300, 100);
  status = sensor.checkStatus();
  if (status == BME68X_ERROR) {
#if FW_SENSOR_DEBUG
    Serial.print("BME688 configuration error: ");
    Serial.println(sensor.statusString());
#endif
    return false;
  }

  found = true;
#if FW_SENSOR_DEBUG
  Serial.print("BME688 initialized successfully at 0x");
  Serial.println(activeAddress, HEX);
#endif
  return true;
}

bool readSensor(SensorReadingSet& readings) {
  readings.clear();
  if (!found) return false;

  bme68xData data;
  sensor.setOpMode(BME68X_FORCED_MODE);
  int8_t status = sensor.checkStatus();
  if (status == BME68X_ERROR) return false;

  delayMicroseconds(sensor.getMeasDur());
  if (!sensor.fetchData()) return false;
  sensor.getData(data);

  float temperature = data.temperature;
  float humidity = data.humidity;
  float pressureHpa = data.pressure / 100.0f;
  float gasResistanceKOhm = data.gas_resistance / 1000.0f;

  if (std::isnan(temperature) || std::isnan(humidity) ||
      std::isnan(pressureHpa) || std::isnan(gasResistanceKOhm)) {
    return false;
  }

#if FW_SENSOR_DEBUG
  Serial.println("----- BME688 reading -----");
  Serial.print("Temperature: "); Serial.print(temperature); Serial.println(" C");
  Serial.print("Humidity: "); Serial.print(humidity); Serial.println(" %");
  Serial.print("Pressure: "); Serial.print(pressureHpa); Serial.println(" hPa");
  Serial.print("Gas resistance: "); Serial.print(gasResistanceKOhm); Serial.println(" kOhm");
  Serial.println("--------------------------");
#endif

  bool ok = true;
  ok = readings.addNumber("temperature", temperature) && ok;
  ok = readings.addNumber("humidity", humidity) && ok;
  ok = readings.addNumber("pressure", pressureHpa) && ok;
  ok = readings.addNumber("gas_resistance", gasResistanceKOhm) && ok;
  return ok;
}

const SensorDriverDefinition definition = {
  "bme688_i2c",
  "BME688 I2C Air Quality Driver",
  beginSensor,
  readSensor
};
}

const SensorDriverDefinition& getBME688SensorDriver() {
  return definition;
}

#endif
