#pragma once

#include "../framework/SensorDriverDefinition.h"

#if FW_ENABLE_SENSOR_SHT31
const SensorDriverDefinition& getSHT31SensorDriver();
#endif
