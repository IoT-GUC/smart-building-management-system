#pragma once

#include "../framework/SensorDriverDefinition.h"

#if FW_ENABLE_SENSOR_BME688
const SensorDriverDefinition& getBME688SensorDriver();
#endif
