#include "../../BuildConfig.h"
#include "SHT31SensorModule.h"

#if FW_ENABLE_SENSOR_SHT31

#include <ArduinoJson.h>
#include <Wire.h>
#include <Adafruit_SHT31.h>
#include <cmath>

namespace {
Adafruit_SHT31 sensor;
bool found = false;
uint8_t activeAddress = 0x44;

uint8_t parseAddress(JsonVariantConst value, uint8_t fallback) {
  if (value.is<unsigned int>()) return static_cast<uint8_t>(value.as<unsigned int>());
  String text = value.as<String>();
  text.trim();
  if (text.length() == 0) return fallback;
  return static_cast<uint8_t>(strtoul(text.c_str(), nullptr, 0));
}

bool beginSensor(const String& configurationJson) {
  found = false;
  uint8_t sdaPin = 21;
  uint8_t sclPin = 22;
  uint8_t preferredAddress = 0x44;
  uint8_t alternateAddress = 0x45;

  if (configurationJson.length() > 0) {
    DynamicJsonDocument doc(512);
    if (deserializeJson(doc, configurationJson) == DeserializationError::Ok) {
      sdaPin = doc["sda_pin"] | sdaPin;
      sclPin = doc["scl_pin"] | sclPin;
      preferredAddress = parseAddress(doc["address"], preferredAddress);
      preferredAddress = parseAddress(doc["i2c_address"], preferredAddress);
      alternateAddress = parseAddress(doc["alternate_address"], alternateAddress);
    }
  }

  Wire.begin(sdaPin, sclPin);

#if FW_SENSOR_DEBUG
  Serial.print("Trying SHT30/SHT31 at 0x");
  Serial.println(preferredAddress, HEX);
#endif

  if (sensor.begin(preferredAddress)) {
    activeAddress = preferredAddress;
    found = true;
  } else if (alternateAddress != preferredAddress && sensor.begin(alternateAddress)) {
    activeAddress = alternateAddress;
    found = true;
  }

#if FW_SENSOR_DEBUG
  if (found) {
    Serial.print("SHT30/SHT31 initialized at 0x");
    Serial.println(activeAddress, HEX);
  } else {
    Serial.println("SHT30/SHT31 initialization failed");
  }
#endif

  return found;
}

bool readSensor(SensorReadingSet& readings) {
  readings.clear();
  if (!found) return false;

  float temperature = sensor.readTemperature();
  float humidity = sensor.readHumidity();
  if (std::isnan(temperature) || std::isnan(humidity)) return false;

#if FW_SENSOR_DEBUG
  Serial.print("Temperature: ");
  Serial.print(temperature);
  Serial.println(" C");
  Serial.print("Humidity: ");
  Serial.print(humidity);
  Serial.println(" %");
#endif

  return readings.addNumber("temperature", temperature) &&
         readings.addNumber("humidity", humidity);
}

const SensorDriverDefinition definition = {
  "sht31_i2c",
  "SHT30/SHT31 I2C Driver",
  beginSensor,
  readSensor
};
}

const SensorDriverDefinition& getSHT31SensorDriver() {
  return definition;
}

#endif
