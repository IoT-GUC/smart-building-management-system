# Smart Building Modular LILYGO Firmware v2

## What this project is

This is one reusable source project based on the working core from `lilygocodefinalCopy.ino`.
It produces several small firmware builds. The provisioning, backend, Preferences and LMIC code remains shared, while only the selected sensor driver and payload encoder are compiled.

## First test: BME688-only build

The default in `BuildConfig.h` is:

```cpp
#define FW_BUILD_PRESET FW_PRESET_BME688_ONLY
```

This build compiles:

- the original provisioning and LoRaWAN core;
- `bme688_i2c` driver;
- `bme688_v1` encoder.

It excludes the SHT31 library and legacy multi encoder.

## Other builds

Change one line in `BuildConfig.h`:

```cpp
#define FW_BUILD_PRESET FW_PRESET_SHT31_ONLY
#define FW_BUILD_PRESET FW_PRESET_ENVIRONMENT_ALL
#define FW_BUILD_PRESET FW_PRESET_LEGACY_MULTI
```

Use only one value at a time.

## Important behavior

The provisioning page now filters the backend profile list. It shows only profiles whose required firmware module and payload encoder exist in the selected build.

The selected profile also provides:

- `sensor_module_key`;
- sensor configuration JSON such as I2C pins/address;
- payload encoder key;
- interval and profile identity.

The firmware stores these values in Preferences and activates the correct compiled module after provisioning or restart.

## Project structure

```text
SmartBuilding_Firmware_Modular_v2.ino  shared core
BuildConfig.h                          build selection
src/framework/                         registry and common telemetry types
src/sensors/                           physical sensor drivers
src/payloads/                          LoRaWAN byte encoders
docs/                                  templates and architecture notes
```

## Arduino IDE instructions

1. Keep the directory name and `.ino` name identical: `SmartBuilding_Firmware_Modular_v2`.
2. Open `SmartBuilding_Firmware_Modular_v2.ino`.
3. Install the same ESP32, LMIC, ArduinoJson and selected sensor libraries used by the original firmware.
4. Select the same LILYGO/ESP32 board and LoRa settings used by the working code.
5. Select a build preset in `BuildConfig.h`.
6. Verify/compile and record the flash percentage.
7. Upload only after compilation succeeds.

## Adding a completely new sensor

1. Create one sensor module under `src/sensors` using the template in `docs`.
2. Create one payload encoder under `src/payloads`.
3. Add one sensor enable switch and one encoder switch to a build preset.
4. Add the module to `SensorRegistry.cpp`.
5. Add the encoder to `PayloadRegistry.cpp`.
6. Create the Sensor Catalog, Firmware Module and Advanced Profile records in the Admin Portal.
7. Compile a small build containing only the required module(s).

The provisioning, Wi-Fi, backend and LMIC core should not be rewritten.

## Migration note

Older provisioned devices may not yet have `sensor_module` and `sensor_config` stored in Preferences. The registry retains compatibility for the existing profile codes `AIR_BME688_V1`, `ENV_SHT31_V1` and `MULTI_LEGACY_V1`. Reprovisioning stores the new module/configuration fields.

## Compile verification

This package was structurally checked in the generation environment, but the full Arduino ESP32/LMIC toolchain was not installed there. The first authoritative test is Arduino IDE **Verify** using your installed board package and libraries.
